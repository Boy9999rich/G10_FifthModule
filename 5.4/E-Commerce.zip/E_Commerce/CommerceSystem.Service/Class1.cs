﻿namespace CommerceSystem.Service
{
    public class Class1
    {

    }
}
