﻿namespace CommerceSystemRepository
{
    public class Class1
    {

    }
}
