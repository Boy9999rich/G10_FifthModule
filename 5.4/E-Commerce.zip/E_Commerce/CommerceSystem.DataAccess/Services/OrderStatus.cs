﻿namespace CommerceSystem.DataAccess.Services;

public class OrderStatus
{
    public long StatusId { get; set; }
    public string StatusName { get; set; }
}
